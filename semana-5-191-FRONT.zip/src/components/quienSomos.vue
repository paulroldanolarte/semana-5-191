<template>
     <section id="quienSomos">
    <div class="flex-container">
      <div class="flex-item text-justify">
        <h2> ¿Quiénes Somos?</h2> <br>
        <P> Somos una empresa colombiana posicionada en el mercado de software de aplicaciones para el fortalecimiento de la gestión empresarial, procesos de facturación y 
          seguridad en datos organizacionales, ajustados a los requerimientos de cada empresasa, independientemente de su tamaño y el sector socioeconómico al que pertenezca.
          
          Nuestro conjunto integral de aplicaciones y servicios permite a nuestros clientes y sus empresas operar de forma rentable, adaptarse continuamente y 
          ser lider de su sector. 
                        
          Nuestra compañía cuenta con un gran equipo de profesionales con experiencia y talento en las áreas de desarrollo, capacitación y soporte; que guían
          y acompañan a las empresas en todo el proceso de implementación del software.. </P>
      </div>


      </div>

  </section>
</template>

<script>
export default {
    name: "QuienSomos",

};

</script>

<style scoped>

</style>
