<template>
    <!-- contenido del servicio -->
  <section id="servicio2">
    <div class="container">
      <div class="content-center">
    <!-- descripcion -->
    <h3 class="descripcion text-center">Maximice el valor de todos los datos estructurados y no estructurados de su organización. </h3> 

	<p>Con funcionalidades excepcionales para la integración,calidad y depuración de datos, soluciones para gestión de datos y de base de datos brindan la capacidad de gestionar las crecientes cantidades de datos almacenados en 
  múltiples ubicaciones con un acceso controlado para que toda su organización analice y actúe sobre una sola versión de la verdad. </p> <br> <br>
</div>
</div> 
    <!-- que es  -->
    <div class="container-fluid">
      <div class="flex-container">
        <div class="flex-item">
          <img src="imagenes/gestionDatos/block1.jpg">
        </div>
        <div class="flex-item">
          <h2>Gestión PACS</h2>
          <h5>mediante nuestra tecnología permitimos la obtención y la administración de los datos de una manera   práctica de recopilar, mantener y utilizar los datos de forma segura, eficiente y rentable. <br> <br>
            
            Nuestros métodos se basan en <b>blockchain</b>, el cual es un sistema de contabilidad distribuida que registra datos (transacciones, archivos o información)a través de una red de dispositivos conectados. donde cada integrante puede ver los datos y verificarlos utilizando  algoritmos; evitando fallas en la información y mejorando la toma de decisiones.
          </h5> <br>
        </div>
      </div>
    </div>
        <!-- beneficios -->
        <div class="container-fluid">
          <div class="flex-container">
            <div class="flex-item">
              <img src="imagenes/gestionDatos/block2.jpg">
            </div>
            <div class="flex-item">
              <h2>Beneficios</h2>
              <h5>	1) Reducción de intermediarios  <br><br>
                2) Mayor transparencia <br><br>
                3) Datos encriptados y por lo tanto mayor seguridad <br><br>
                4) Acceso a datos para una perspectiva más amplia <br><br>
                5) Lograr la excelencia en la gestión de la información <br><br>
                6) Conectar datos para descubrir información estratégica.  <br>   <br>           
              </h5>
            </div>
          </div>
        </div>
            <!-- caracteristicas -->
            <div class="container-fluid">
              <div class="flex-container">
                <div class="flex-item">
                  <img src="imagenes/gestionDatos/block3.jpg">
                </div>
                <div class="flex-item">
                  <h3>¿Cómo evitar y detectar fallas de datos a la hora de la gestión empresarial?</h3> <br>
                  <h5>Dado el funcionamiento del blockchain cada bloque tiene un lugar específico e inamovible dentro de la cadena, ya que cada bloque contiene información del bloque anterior.
                    La cadena completa se guarda en cada nodo de la red que conforma, por lo que se almacena una copia exacta de la cadena en todos los participantes de la red. <br>

                    A medida que se crean nuevos registros, estos son primeramente verificados y validados por los nodos de la red y luego añadidos a un nuevo bloque que se enlaza a la cadena..<br> <br>
                  </h5>
                </div>
              </div>
            </div>

  </section>
</template>

<script>
export default {
    name: "ContenidoDatos"
    
}
</script>

<style>

</style>