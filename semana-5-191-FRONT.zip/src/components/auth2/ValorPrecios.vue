<template>
    <!-- precios -->
  <section>
  <div class="pricing-header px-3 py-3 pt-md-5 pb-md-4 mx-auto text-center">
    <h1 class="display-4">Precios</h1>
  </div>

  <div class="container">
    <div class="card-deck mb-3 text-center">
      <div class="card mb-4 shadow-sm">
        <div class="card-header">
          <h4 class="my-0 font-weight-normal">Básico</h4>
        </div>
        <div class="card-body">
          <h1 class="card-title pricing-card-title">$33.000 <small class="text-muted">/ mes</small></h1>
          <ul class="list-unstyled mt-3 mb-4">
            <li>600 documentos electrónicos anuales</li>
            <li> Certificado digital</li>
            <li> Asistencia telefónica en el proceso</li>
            <li> 2 usuarios</li>
          </ul>
        </div>
      </div>
      <div class="card mb-4 shadow-sm">
        <div class="card-header">
          <h4 class="my-0 font-weight-normal">Avanzado</h4>
        </div>
        <div class="card-body">
          <h1 class="card-title pricing-card-title">$ 57.000 <small class="text-muted">/ mes</small></h1>
          <ul class="list-unstyled mt-3 mb-4">
            <li>1200 documentos</li>
            <li>certificado digital</li>
            <li> 	Asistencia telefónica y teleconferencia en el proceso</li>
            <li>4 usuarios</li>
          </ul>
        </div>
      </div>
      <div class="card mb-4 shadow-sm">
        <div class="card-header">
          <h4 class="my-0 font-weight-normal">Premium</h4>
        </div>
        <div class="card-body">
          <h1 class="card-title pricing-card-title">$ 160.000 <small class="text-muted">/ mes</small></h1>
          <ul class="list-unstyled mt-3 mb-4">
            <li>6000 documentos</li>
            <li>certificado digital</li>
            <li> Asistencia telefónica y teleconferencia en el proceso</li>
            <li>6 usuarios</li>
          </ul>
        </div>
      </div>
    </div>
  </div>
  </section>
<!-- Fin de los precios -->
</template>
<script>
export default {
    name:"ValorPrecios"
}
</script>

<style>

</style>