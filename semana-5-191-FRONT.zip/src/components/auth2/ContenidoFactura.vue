<template>
    <!-- contenido del servicio -->
  <section id="servicio1">
    <!-- que es  -->
    <div class="container-fluid">
      <div class="flex-container">
        <div class="flex-item">
          <img src="imagenes/facturacion/factura1.png">
        </div>
        <div class="flex-item">
          <h2>Factura CASP</h2>
          <h5>Es la factura electrónica CASP creada para la emisión de documentos electrónicos. Podrá generar Documentos
            Tributarios Electrónicos(DTE).
            Esta solución ofrece un panorama real y unificado sobre las operaciones a nivel de la administración de las
            relaciones con los clientes, las facturas y las finanzas.
            Los usuarios podrán tener el control y una visión completa de la información actualizada al momento de
            querer tomar decisiones importantes para la empresa.
          </h5>
        </div>
      </div>
    </div>
        <!-- beneficios -->
        <div class="container-fluid">
          <div class="flex-container">
            <div class="flex-item">
              <h2>Beneficios</h2>
              <h5>•	Cumple con todos los requerimientos exigidos por la DIAN. <br>
                •	Agiliza la captura de documentos al asociar una cotización a una factura. <br>
                •	Módulos de Alertas <br>
                •	Consulta web para la visualización de documentos electrónicos emitidos. <br>
                •	Validación de documentos electrónicos previo a ser emitidos. <br>
                •	Distribución automática por cada documento electrónico emitido.  <br>              
              </h5>
            </div>
            <div class="flex-item">
              <img src="imagenes/facturacion/factura2.jpg">
            </div>
          </div>
        </div>
            <!-- caracteristicas -->
            <div class="container-fluid">
              <div class="flex-container">
                <div class="flex-item">
                  <img src="imagenes/facturacion/factura1.png">
                </div>
                <div class="flex-item">
                  <h3>¿Cómo evitar y detectar fallas de datos a la hora de la facturación?</h3> <br>
                  <h5>Tendremos a la mano para ti, un líder de Proyecto que te ayudará con la configuración requerida para tu negocio, la factura electrónica tendrá un software especializado que agiliza los procesos teniendo en cuenta las normativas de la DIAN. <br>
                    Para la emisión de las facturas electrónicas se tomarán en cuenta los siguientes aspectos.<br> <br>
                    •	Facturas electrónicas que se emitan con datos claros y sin errores, especificando cada uno de los datos necesarios. <br>
                    •	Facturas electrónicas enviadas a tiempo, para asegurar los pagos con prontitud. <br>
                    •	Hacer un seguimiento responsable del proceso de facturación electrónica <br>
                  </h5>
                </div>
              </div>
            </div>
  </section>
</template>

<script>
export default {
    name: "ContenidoFactura"
    
}
</script>

<style>

</style>