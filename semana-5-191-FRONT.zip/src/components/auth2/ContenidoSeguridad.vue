<template>
    <!-- contenido del servicio -->
    <section id="servicio1">
        <!-- que es  -->
        <div class="container-fluid">
            <div class="flex-container">
                <div class="flex-item">
                    <img src="imagenes/facturacion/factura1.png">
                </div>
                <div class="flex-item">
                    <h2>Gestión e implementación de seguridad</h2>
                    <h5>La frecuencia y magnitud de las filtraciones de datos van en aumento y la pérdida de
                        informaciones
                        puede poner en riesgo una serie de actividades empresariales. Todavía mas cuando se trata de
                        documentos que exigen confidencialidad. <br> <br>
                        Podemos ayudarle a crear políticas de privacidad, establecer los procedimientos y controles
                        operativos usando una perspectiva técnica, normativa y legal.
                    </h5>
                </div>
            </div>
        </div>
        <!-- beneficios -->
        <div class="container-fluid">
            <div class="flex-container">
                <div class="flex-item">
                    <h2>Fuga y Clasificación de datos </h2>
                    <h5>Nuestra empresa brinda herramientas en depurar sus
                        políticas y procedimientos de clasificación de datos
                        para cumplir de manera más eficaz con las normas y
                        obtener más valor de sus datos. <br> <br>
                        Trabajamos juntos para diseñar una estrategia de
                        prevención de fugas de datos y seleccionar las
                        tecnologías más apropiadas

                    </h5>
                </div>
                <div class="flex-item">
                    <img src="imagenes/facturacion/factura2.jpg">
                </div>
            </div>
        </div>
        <!-- caracteristicas -->
        <div class="container-fluid">
            <div class="flex-container">
                <div class="flex-item">
                    <img src="imagenes/facturacion/factura1.png">
                </div>
                <div class="flex-item">
                    <h3>Certificaciones</h3> <br>
                    <h5>Le ayudamos a comprender qué datos privados se
                        recogen y dónde se almacenan, capacitar a los
                        empleados sobre la política de la empresa con
                        relación al manejo de datos privados, implementar
                        un proceso de gestión de riesgos de privacidad <br> <br>
                        Nuestra empresa lidera el uso de herramientas que serán responsables por gestionar los
                        mecanismos de control de acceso, tanto por los colaboradores de la empresa y clientes, reguardando y tornando seguras informaciones importantes. Además de eso, es importante mantener un buen sistema de Backup conactualizaciones continúas, para que la empresa no sufra grande pérdidas de contenidos.
                    </h5>
                </div>
            </div>
        </div>
    </section> 
</template>

<script>
export default {
    name: "ContenidoSeguridad"
}
</script>