<template>
    <!-- inicio Team -->
  <section id="perfiles" class="bg-light-grey">
    <div class="container">
      <div class="content-center">
        <h2>Contamos con el mejor <br> <b>equipo de trabajo.</b></h2>
        <p> En PACS contamos con un equipo de profesionales, ingenieros y administrativos con un alto grado de
          compromiso y responsabilidad que están en constante innovación, desarrollando y materializando soluciones de
          <b>gestión empresarial.</b>
        </p>
      </div>
      <div class="content">
      <div class="row">
        <!-- team1 -->
        <div class="cold-md-4">
          <div class="flip-card">
            <div class="flip-card-inner">
              <div class="flip-card-front">
                <div class="team-container">
                  <div class="team-details">
                    <h5>SEBASTIAN RIAÑO</h5>
                    <span>ADMINISTRADOR DEPORTIVO</span>
                  </div>
                  <img src="imagenes/Sebastian.jpg" class="img-fluid" alt="team1"
                    style="max-width: 300px; max-height: 300px; margin: 20px; box-shadow: 0 2px 4px 0 rgba(0, 0, 0, 0.5) ;">
                </div>
              </div>
              <div class="flip-card-back">
                <h5 class="margento">Amante del futbol , el ciclismo y las artes audiovisuales , interesado en el
                  desarrollo de software enfocado tanto para la gerencia de entidades deportivas , como para la gestión y análisis de disciplinas deportivas. </h5>
              </div>
            </div>
          </div>
        </div>
        <!-- team2 -->
        <div class="cold-md-4">
          <div class="flip-card">
            <div class="flip-card-inner">
              <div class="flip-card-front">
                <div class="team-container">
                  <div class="team-details">
                    <h5>ALEJANDRO BERMÚDEZ</h5>
                    <span>INGENIERO MECÁNICO</span>
                  </div>
                  <img src="imagenes/Alejandro.jpg" class="img-fluid" alt="team2"
                    style="max-width: 300px; max-height: 300px; margin: 20px; box-shadow: 0 2px 4px 0 rgba(0, 0, 0, 0.5) ;">
                </div>
              </div>
              <div class="flip-card-back">
                <h5 class="margento">Egresado de la Universidad Nacional de Colombia, me gusta hacer ejercicio, practica running y futbol, interesado en la programación, uso eficiente de la energía, energías renovables y automatización industrial.</h5>
              </div>
            </div>
          </div>
        </div>

        <!-- team3 -->
        <div class="cold-md-4">
          <div class="flip-card">
            <div class="flip-card-inner">
              <div class="flip-card-front">
                <div class="team-container">
                  <div class="team-details">
                    <h5>PAUL ROLDÁN</h5>
                    <span>BIOINGENIERO</span>
                  </div>
                  <img src="imagenes/Paul.jpg" class="img-fluid" alt="team3"
                    style="max-width: 300px; max-height: 300px; margin: 20px; box-shadow: 0 2px 4px 0 rgba(0, 0, 0, 0.5) ;">
                </div>
              </div>
              <div class="flip-card-back">
                <h5 class="margento">Apasionado de la biotecnología y la ingeniería aplicada a proyectos relacionados con el campo de la agricultura, la biodiversidad y la sostenibilidad. Amante de la natación con aletas y el deporte en general.</h5>
              </div>
            </div>
          </div>
        </div>
        <!-- team4 -->
        <div class="cold-md-4">
          <div class="flip-card">
            <div class="flip-card-inner">
              <div class="flip-card-front">
                <div class="team-container">
                  <div class="team-details">
                    <h5>CRISTIAN FERNEY</h5>
                    <span>LICENCIADO EN FISICA</span>
                  </div>
                  <img src="imagenes/Cristian.jpg" class="img-fluid" alt="team4"
                    style="max-width: 300px; max-height: 300px; margin: 20px; box-shadow: 0 2px 4px 0 rgba(0, 0, 0, 0.5) ;">
                </div>
              </div>
              <div class="flip-card-back">
                <h5 class="margento">Egresado de la Universidad Distrital Francisco Jose de Caldas,estudiante de maestria, enamorado de la ciencia la musica y la comida , interesado en enseñanza atraves de la programación. .</h5>
              </div>
            </div>
          </div>
        </div>

      </div>
      </div>
    </div>
    
  </section>
  <!-- fin del team -->

</template>

<script>
export default {
    name: "WorkTeam"    
}
</script>

<style scoped>

</style>