<template>
     <section id="footer" style="background-color:#455a64;">
    <div class="container">
      <div class="row">
        <div class="col-md-4 footer-col">
    <img src="imagenes/logoblanco.jpeg" class="logo-brand" alt="logo">
    <ul class="list-inline">
      <li class="list-inline-item-footer-menu"><p>Encuentranos en:</p></li>
      <li class="list-inline-item-footer-menu"><p><v-icon medium color="teal darken-0"> mdi-map </v-icon> Bogotá D.C.</p></li>
      <li class="list-inline-item-footer-menu"><p><v-icon medium color="teal darken-0"> mdi-map </v-icon>Bucaramanga</p></li>
      <li class="list-inline-item-footer-menu"><p><v-icon medium color="teal darken-0"> mdi-map </v-icon> Cali</p></li>
      <li class="list-inline-item-footer-menu"><p><v-icon medium color="teal darken-0"> mdi-map </v-icon> Medellín</p></li>
      <li class="list-inline-item-footer-menu"><p><v-icon medium color="teal darken-0"> mdi-map </v-icon> Pereira</p></li>
    </ul>
        </div>
    <div class="col-md-4 footer-col">
      <br> <br>
    <h3>Contáctanos</h3> <br>
    <ul class="list-inline">
      <li class="list-inline-item-footer-menu"><p><v-icon medium color="teal darken-1"> mdi-email </v-icon> prueba@gmail.com</p></li> <br>
      <li class="list-inline-item-footer-menu"><p> <v-icon medium color="teal darken-1"> mdi-cellphone </v-icon> +57 300 123456</p></li> <br>
      <li class="list-inline-item-footer-menu"><p> <v-icon medium color="teal darken-1"> mdi-phone </v-icon> (1) 1564545</p></li> <br>
    </ul>
    </div>
    <div class="col-md-4 footer-col">
      <br><br>
    <h3>Repositorio</h3> <br> <br>
    <button type="button" class="btn btn-outline-info"> <v-icon large color="blue"> mdi-arrow-right </v-icon> Ir al Repositorio</button>
    </div>
  </div>
    </div>
     </section>
</template>

<script>
export default {
    name: "pageFooter", 
};
</script>

<style scoped>

</style>