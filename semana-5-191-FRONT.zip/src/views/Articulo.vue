<template>
    <tabla-datos-articulo></tabla-datos-articulo>
</template>

<script>

import TablaDatosArticulo from '../components/TablaDatosArticulo.vue'
export default {
    components:{
        TablaDatosArticulo
    }
    
}
</script>