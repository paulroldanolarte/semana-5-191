<template>
    <tabla-datos-usuario></tabla-datos-usuario>
</template>

<script>


import TablaDatosUsuario from '../components/TablaDatosUsuario.vue'
export default {
    components:{

        TablaDatosUsuario
    }
    
}
</script>