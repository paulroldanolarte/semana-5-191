<template>
    <tabla-datos-categorias></tabla-datos-categorias>
</template>

<script>

import TablaDatosCategorias from '../components/TablaDatosCategorias.vue'
export default {
    components:{
        TablaDatosCategorias
    }
    
}
</script>