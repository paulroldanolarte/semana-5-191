<template>

<the-login></the-login>

</template>

<script>
import TheLogin from '../components/TheLogin.vue'

export default {
  components: { TheLogin },
    
}
</script>

<style scoped>



</style>